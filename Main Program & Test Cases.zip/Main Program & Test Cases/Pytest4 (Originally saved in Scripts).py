import pytest

def missing_ISBN_percentage(nullcount, totalrows):
    return round((nullcount / totalrows) * 100, 1)

def test_missing_ISBN_percentage():
    assert missing_ISBN_percentage(9, 604) == 0.15
