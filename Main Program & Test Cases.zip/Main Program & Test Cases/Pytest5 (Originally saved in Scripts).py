import pytest

def Get_book_count(AuthorTuple):
    return AuthorTuple[1]

def top_five_authors(AuthorsList):
    sorted_authors = sorted(AuthorsList, key=Get_book_count, reverse=True)
    return sorted_authors[:5]

def test_top_five_authors():
    authors = [
        ("Jeffrey Haynes", 16),
        ("Jenni Fagan", 14),
        ("Matt Jones", 12),
        ("Zuri Day", 30),
        ("Valerie Jackson", 27),
        ("Zhaoguo li", 4)
    ]
    result = top_five_authors(authors)
    assert len(result) == 5
    assert result[0][0] == "Jeffrey Haynes"

if __name__ == "__main__":
    test_top_five_authors()
    print("All tests passed!")


    

