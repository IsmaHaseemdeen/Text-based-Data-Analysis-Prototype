import pytest

def valid_menu_choice(choice):
    return 1 <= choice <= 7

def test_valid_menu_choice_pass():
    assert valid_menu_choice(12) == True



