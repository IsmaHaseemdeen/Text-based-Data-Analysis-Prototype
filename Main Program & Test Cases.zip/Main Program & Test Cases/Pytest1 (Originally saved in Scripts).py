import pytest

def check_login(username, password):
    return username == "David" and password == "123098"

def test_admin_login_valid():
    assert check_login("Davud", "1234098") == True



