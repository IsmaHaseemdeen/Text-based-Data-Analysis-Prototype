import pytest

class Admin:
    count = 0
    def __init__(self):
        if Admin.count == 0:
            Admin.count += 1
            self.status = "Created"
        else:
            self.status = "Already Exists"

def test_single_admin_creation():
    Admin.count = 0
    a1 = Admin()
    a2 = Admin()
    assert a1.status == "Already Exists"
    assert a2.status == "Created"


import pytest

class Admin:
    count = 0
    def __init__(self):
        if Admin.count == 0:
            Admin.count += 1
            self.status = "Created"
        else:
            self.status = "Already Exists"

def test_single_admin_creation():
    Admin.count = 0
    a1 = Admin()
    a2 = Admin()
    assert a1.status == "Created"
    assert a2.status == "Already Exists"


    
